
public enum Action {
	TURN_ON,
	TURN_OFF,
	TURN_RIGHT,
	TURN_LEFT,
	GO,
	SUCK
}